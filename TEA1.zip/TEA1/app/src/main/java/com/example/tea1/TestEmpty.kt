package com.example.tea1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class TestEmpty : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_empty)
    }
}